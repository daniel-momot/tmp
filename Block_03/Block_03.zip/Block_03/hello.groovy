import java.sql.*; 
import groovy.sql.Sql 
import groovy.json.JsonOutput 

class Example {
	static void main(String[] args) {
		def get = new URL("http://localhost:8080").openConnection();
		if(get.getResponseCode() == 200) {
			def text = get.getInputStream().getText();
			if (text.equals("yes")) {
				def sql = Sql.newInstance('jdbc:mysql://localhost:3306/TESTDB', 'testuser', 'test123', 'com.mysql.jdbc.Driver');				
				sql.eachRow('select * from employee') {
					tp -> 
					println(JsonOutput.toJson([name: tp.FIRST_NAME, surname: tp.LAST_NAME, age: tp.AGE]));  
				}				
				sql.close();
			}
		}
	}
}